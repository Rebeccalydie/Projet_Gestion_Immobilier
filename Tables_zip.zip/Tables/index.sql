@Tables/ACHATS.sql


@Tables/CLIENTS.sql

@Tables/FAVORIS.sql

@Tables/MAISONS_LOCATIONS.sql


@Tables/MAISONS_VENTES.sql


@Tables/PAYS.sql


@Tables/PROPRIETAIRES.sql


@Tables/PUBLICATIONS.sql


@Tables/RESERVATIONS.sql


@Tables/VILLES.sql

@Tables/SIGNALER.sql