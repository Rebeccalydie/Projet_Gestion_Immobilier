ALTER TABLE SIGNALER
ADD
CONSTRAINT signal_fk
FOREIGN KEY (id_client)
REFERENCES clients (id_client);