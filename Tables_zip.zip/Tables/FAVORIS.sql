CREATE TABLE FAVORIS
(
    id_favoris INT NOT NULL,
    id_client INT NOT NULL,
    id_Mlocation VARCHAR2(20) NOT NULL
);